import Application, { PROGRAM_LABELS } from "../models/application.model.js";
import { ApiError, ok } from "../utils/response.util.js";
import asyncHandler from "../utils/asyncHandler.util.js";
import {
  sendApplicationReceivedEmail,
  sendApplicationNotificationEmail,
} from "../utils/email.util.js";

// Shared by all three program routes — the program type comes from the
// validated :program route param (see application.routes.js), so each of
// /api/applications/internship, /residency, /caregiver hits this once.
export const submitApplication = asyncHandler(async (req, res) => {
  const { program } = req.params;
  const { fullName, email, phone, message } = req.body;
  const programLabel = PROGRAM_LABELS[program];

  const application = await Application.create({
    programType: program,
    fullName,
    email,
    phone,
    message,
  });

  // Application is saved regardless of whether these emails succeed —
  // don't let a flaky SMTP connection lose someone's submission.
  try {
    await sendApplicationNotificationEmail({
      programLabel,
      fullName,
      email,
      phone,
      message,
    });
    await sendApplicationReceivedEmail(email, fullName, programLabel);
  } catch (err) {
    console.error("Application email failed to send:", err.message);
  }

  return ok(
    res,
    201,
    `Your ${programLabel} application has been received.`,
    application
  );
});

// Admin-facing: list applications, optionally filtered by program type.
export const getApplications = asyncHandler(async (req, res) => {
  const { program, status } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
  const skip = (page - 1) * limit;

  const filter = {};
  if (program) filter.programType = program;
  if (status) filter.status = status;

  const [applications, total] = await Promise.all([
    Application.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
    Application.countDocuments(filter),
  ]);

  return ok(res, 200, "Applications fetched", {
    applications,
    pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
  });
});

export const getApplicationById = asyncHandler(async (req, res) => {
  const application = await Application.findById(req.params.id);
  if (!application) throw new ApiError(404, "Application not found");
  return ok(res, 200, "Application fetched", application);
});
