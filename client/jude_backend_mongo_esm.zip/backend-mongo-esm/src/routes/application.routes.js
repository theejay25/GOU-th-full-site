import express from "express";
import { body, param, query } from "express-validator";
import rateLimit from "express-rate-limit";
import validate from "../middleware/validate.middleware.js";
import { protect } from "../middleware/auth.middleware.js";
import { PROGRAM_TYPES } from "../models/application.model.js";
import {
  submitApplication,
  getApplications,
  getApplicationById,
} from "../controllers/application.controller.js";

const router = express.Router();

// Prevents the application form from being used to spam emails/DB writes.
const applyLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: "Too many applications submitted, please try again later",
  },
});

const applicationValidators = [
  param("program")
    .isIn(PROGRAM_TYPES)
    .withMessage(`Program must be one of: ${PROGRAM_TYPES.join(", ")}`),
  body("fullName").trim().notEmpty().withMessage("Full name is required"),
  body("email").trim().isEmail().withMessage("A valid email is required"),
  body("phone").optional().trim(),
  body("message").optional().trim(),
];

// This one route pattern serves all three required endpoints:
//   POST /api/applications/internship
//   POST /api/applications/residency
//   POST /api/applications/caregiver
router.post("/:program", applyLimiter, applicationValidators, validate, submitApplication);

// Admin-facing: view submitted applications (protected — any logged-in user
// for now; add a role/permission check here if you introduce admin accounts).
router.get(
  "/",
  protect,
  [query("program").optional().isIn(PROGRAM_TYPES)],
  validate,
  getApplications
);

router.get(
  "/:id",
  protect,
  [param("id").isMongoId().withMessage("Invalid application id")],
  validate,
  getApplicationById
);

export default router;
